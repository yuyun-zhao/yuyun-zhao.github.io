package com.atguigu.spring5.dao;

public interface UserDao {
    //多钱
    public void addMoney();
    //少钱
    public void reduceMoney();
}
