package com.atguigu.spring5.aopxml;

public class Book {
    public void buy() {
        System.out.println("buy.............");
    }
}
