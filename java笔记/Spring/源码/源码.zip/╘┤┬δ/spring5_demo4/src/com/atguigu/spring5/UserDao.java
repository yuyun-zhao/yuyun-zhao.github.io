package com.atguigu.spring5;

public interface UserDao {
    public int add(int a,int b);
    public String update(String id);
}
