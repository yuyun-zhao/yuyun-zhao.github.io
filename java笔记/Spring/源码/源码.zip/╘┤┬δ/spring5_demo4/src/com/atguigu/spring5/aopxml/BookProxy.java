package com.atguigu.spring5.aopxml;

public class BookProxy {
    public void before() {
        System.out.println("before.........");
    }
}
