# 一、补充

[juc最新笔记，补充了AQS等知识(含测试代码)]( https://github.com/RingoTangs/java-util-concurrent)

[RabbitMQ消息可靠性投递、避免消息重复消费(流程图 + 测试代码)]( https://github.com/RingoTangs/spring-boot-rabbitmq-delivery)

[Redis应用场景、Redisson分布式锁、Redis内存淘汰策略、LRU算法](https://github.com/RingoTangs/redis-redlock)

[Spring Security 自定义校验逻辑，支持图片验证码、短信验证码登录（支持JSON和表单登录）](https://github.com/RingoTangs/spring-security-login-demo)